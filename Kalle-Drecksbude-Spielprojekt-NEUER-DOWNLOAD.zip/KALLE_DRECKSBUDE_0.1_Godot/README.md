# KALLE – DRECKSBUDE 0.1 (Godot-Quellprojekt)

Dies ist ein **neues, eigenständiges** Offline-Godot-Spielprojekt und **nicht** das von Work begonnene Projekt. Das Work-Projekt war beim Erstellen nicht verfügbar. Die vier vorhandenen Originalgrafiken aus der ChatGPT-Bibliothek wurden verarbeitet.

## Was diese Grundversion wirklich enthält

- Ein illustriertes Apartment im Querformat, keine Homescreen-Widget-Funktion.
- Kalle als **8-teiliges Sprite-Rig** mit Idle-Bewegung, Gehen, Schimpfen und Tanzen; Übergänge sind bewusst einfach. Es sind **noch keine hochwertigen, voll ausanimierten 50 Bewegungen**.
- Touch-Steuerung: Boden antippen, Kalle geht dorthin; Kalle selbst oder Möbel anklicken.
- Sechs grafisch getrennte Einrichtungsobjekte plus anklickbare Tür und Fenster.
- 50+ kontextbezogene Dialoge, Wiederholungssperre und automatisch verschwindende Sprechblase.
- Fünf kleine Geheimnisse / Sammelereignisse.
- Audio-Beep-Effekte, TV-Glühen, Tag/Nacht-Tönung, Stimmungsreaktionen.
- Lokales Speichern von Punkten, Geheimnissen und Interaktionszählern.
- Keine Netzwerkberechtigungen, kein Cloud-Zwang.

## So startest du es

1. Godot **4.4.x** Standard-Version installieren (GDScript; keine .NET-Version erforderlich).
2. Diesen Projektordner in Godot importieren (`project.godot`).
3. Hauptszene `scenes/Main.tscn` mit **F6** oder das Spiel mit **F5** starten.
4. Android: Android-SDK/JDK und Godot-Android-Exporttemplates einrichten, neues Release-/Debug-Exportpreset anlegen und eigene Paketkennung verwenden: `de.boyka.kalle.drecksbude`.

**Wichtig:** Dieser Quellstand wurde außerhalb der Godot-Engine zusammengestellt. Da in der aktuellen Arbeitsumgebung keine Godot-Binary und kein Android-SDK vorhanden waren, **konnten ein echter Godot-Import, Starttest und APK-Export nicht ausgeführt werden**. Es wird deshalb ausdrücklich keine funktionierende APK behauptet. Ein erster Test mit der Godot-Engine ist vor Freigabe nötig.

## Fehlende Punkte im Vergleich zum Master-Prompt

Der komplette Work-Projektstand, seine potentiell vorhandene APK sowie der Originalquellcode konnten nicht abgerufen werden. Dieses Projekt ist eine neue kleine Grundversion. Weitere Räume, NPCs, viele zusätzliche Animationen und Mini-Spiele sind noch **nicht** integriert.

## Rechte

Die eingebauten Illustrationen stammen aus den bereits für dieses Nutzerprojekt erstellten/generierten Bildassets. Die Skripte und Soundeffekte wurden für diesen Prototyp neu erstellt.
