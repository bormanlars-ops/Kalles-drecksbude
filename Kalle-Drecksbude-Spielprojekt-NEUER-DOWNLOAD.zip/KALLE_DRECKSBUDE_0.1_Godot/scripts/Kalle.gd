extends Node2D
## Multi-part original Kalle sprite rig, floor-relative coordinates.

signal arrived

const SPEED: float = 190.0
const MIN_X: float = 115.0
const MAX_X: float = 1170.0
var target_x: float = 690.0
var traveling: bool = false
var mood: String = "idle"
var clock: float = 0.0
var parts: Dictionary = {}
var face_right: bool = true

const BASE: Dictionary = {
    "leg_left": Vector2(-24, -105), "leg_right": Vector2(25, -105),
    "boot_left": Vector2(-35, -27), "boot_right": Vector2(38, -27),
    "body": Vector2(0, -201),
    "arm_left": Vector2(-71, -193), "arm_right": Vector2(70, -193),
    "head": Vector2(-3, -292)
}

func _ready() -> void:
    _part("leg_left", "leg_a", BASE["leg_left"], Vector2(0.27, 0.28), -1)
    _part("leg_right", "leg_b", BASE["leg_right"], Vector2(0.27, 0.28), 1)
    _part("boot_left", "boot", BASE["boot_left"], Vector2(0.145, 0.145), -1)
    _part("boot_right", "boot", BASE["boot_right"], Vector2(0.145, 0.145), 1)
    _part("arm_left", "arm", BASE["arm_left"], Vector2(0.28, 0.28), -1)
    _part("body", "body", BASE["body"], Vector2(0.35, 0.35), 0)
    _part("arm_right", "arm", BASE["arm_right"], Vector2(0.28, 0.28), 1)
    _part("head", "head", BASE["head"], Vector2(0.29, 0.29), 0)
    target_x = position.x

func _part(key: String, filename: String, pos: Vector2, size: Vector2, z: int) -> void:
    var sprite: Sprite2D = Sprite2D.new()
    sprite.name = key
    sprite.texture = load("res://assets/characters/%s.png" % filename) as Texture2D
    sprite.position = pos
    sprite.scale = size
    sprite.z_index = z
    if key == "arm_left": sprite.flip_h = true
    add_child(sprite)
    parts[key] = sprite

func walk_to(x: float) -> void:
    target_x = clampf(x, MIN_X, MAX_X)
    traveling = absf(target_x - position.x) > 5.0
    mood = "walk" if traveling else "idle"
    if not traveling: arrived.emit()

func emote(which: String) -> void:
    mood = which

func _process(delta: float) -> void:
    clock += delta
    if traveling:
        var step: float = SPEED * delta
        var direction: float = signf(target_x - position.x)
        position.x = move_toward(position.x, target_x, step)
        if absf(target_x - position.x) <= 1.0:
            traveling = false
            mood = "idle"
            arrived.emit()
    var cycle: float = clock * (12.0 if traveling else 1.8)
    var walk_power: float = 1.0 if traveling else 0.0
    (parts["leg_left"] as Sprite2D).rotation = sin(cycle) * 0.17 * walk_power
    (parts["leg_right"] as Sprite2D).rotation = -sin(cycle) * 0.17 * walk_power
    (parts["boot_left"] as Sprite2D).position = BASE["boot_left"] + Vector2(0, -absf(sin(cycle)) * 11.0 * walk_power)
    (parts["boot_right"] as Sprite2D).position = BASE["boot_right"] + Vector2(0, -absf(cos(cycle)) * 11.0 * walk_power)
    (parts["body"] as Sprite2D).position = BASE["body"] + Vector2(0, sin(cycle * 1.5) * (3.0 if traveling else 1.2))
    (parts["head"] as Sprite2D).position = BASE["head"] + Vector2(sin(clock * 0.7) * 2.0, sin(cycle) * (2.0 if traveling else 1.0))
    var arm_base: float = 0.05 * sin(clock * 1.6)
    (parts["arm_left"] as Sprite2D).rotation = arm_base - sin(cycle) * 0.12 * walk_power
    (parts["arm_right"] as Sprite2D).rotation = -arm_base + sin(cycle) * 0.12 * walk_power
    if mood == "angry":
        (parts["arm_left"] as Sprite2D).rotation = -0.65 + sin(clock * 15.0) * 0.2
        (parts["arm_right"] as Sprite2D).rotation = 0.65 - sin(clock * 15.0) * 0.2
        (parts["head"] as Sprite2D).rotation = sin(clock * 14.0) * 0.07
    elif mood == "dance":
        (parts["arm_left"] as Sprite2D).rotation = -0.95 + sin(clock * 10.0) * 0.4
        (parts["arm_right"] as Sprite2D).rotation = 0.95 + cos(clock * 10.0) * 0.4
        (parts["head"] as Sprite2D).rotation = sin(clock * 6.0) * 0.13
    else:
        (parts["head"] as Sprite2D).rotation = sin(clock * 0.95) * 0.025
