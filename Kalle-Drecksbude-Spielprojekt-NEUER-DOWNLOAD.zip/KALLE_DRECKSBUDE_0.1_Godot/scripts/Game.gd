extends Node2D
## KALLE – DRECKSBUDE. A real Godot 4 interactive one-room vertical slice.
## No home-screen widget. No external connectivity. Everything stays in user://.

const KALLE_SCRIPT: Script = preload("res://scripts/Kalle.gd")
const SAVE_FILE: String = "user://kalle_drecksbude_0_1.json"
const GROUND_Y: float = 668.0
const PROP_SPECS: Dictionary = {
    "sofa": {"pos": Vector2(204, 526), "size": Vector2(377, 226), "approach": 418.0},
    "tv": {"pos": Vector2(667, 465), "size": Vector2(247, 314), "approach": 780.0},
    "lamp": {"pos": Vector2(1040, 466), "size": Vector2(128, 316), "approach": 966.0},
    "radio": {"pos": Vector2(906, 516), "size": Vector2(151, 130), "approach": 850.0},
    "trash": {"pos": Vector2(503, 597), "size": Vector2(149, 180), "approach": 577.0},
    "table": {"pos": Vector2(905, 597), "size": Vector2(279, 180), "approach": 805.0}
}
const PHRASES: Dictionary = {
    "intro": [
        "Willkommen in meiner Bude. Schuhe aus – ach, scheiß drauf.",
        "Fass bloß nichts an. Hier ist alles entweder kaputt oder verflucht."
    ],
    "idle": [
        "Ich wollte mein Leben ändern. Hab mich dann hingesetzt.",
        "Die Tapete hält nur noch aus Trotz.",
        "Wenn Faulheit olympisch wär, würd ich die Anmeldung verpennen.",
        "Mein Kühlschrank hat mehr Zukunftspläne als ich.",
        "Was glotzt du so? Noch nie 'nen Profi im Nichtstun gesehen?",
        "Ich glaub, der Müll zahlt hier mittlerweile Miete.",
        "Diese Wohnung hat Charakter. Und wahrscheinlich Schimmel.",
        "Ich müsste mal aufräumen. Irgendwann zwischen nie und niemals.",
        "Ich hab Hunger. Aber zum Kühlschrank laufen ist auch Arbeit.",
        "Wer diese Bude renoviert, braucht keine Feinde mehr."
    ],
    "sofa": [
        "Die Couch ist nicht dreckig, die hat Patina, du Kulturbanaus!",
        "Wenn dieses Sofa reden könnte, würd es einen Anwalt verlangen.",
        "Hier sitz ich seit Dienstag. Welcher Dienstag? Keine Ahnung.",
        "Meine Couch hat mehr erlebt als dein WLAN-Router.",
        "Wenn du mich suchst: Ich bin beruflich am Liegen."
    ],
    "tv": [
        "Das Programm ist so beschissen, ich guck lieber die Staubschicht an.",
        "Halt die Fresse, Fernseher. Ich weiß, dass du kaputt bist!",
        "Da laufen Leute rum, die noch planloser sind als ich.",
        "Breaking News: Mein Lebenslauf ist wieder auf Sendung.",
        "Die Kiste ist älter als meine Ausreden."
    ],
    "lamp": [
        "Guck mal, Licht! Die Stromrechnung kriegt gleich 'nen Herzinfarkt.",
        "Diese Lampe flackert mehr als meine Lebensplanung.",
        "Hell genug, um den ganzen Dreck zu sehen. Schlechte Idee.",
        "Fass den Schalter nicht dauernd an, du Stromkobold!"
    ],
    "radio": [
        "Was für ein Sender ist das? Radio Restmüll?",
        "Ich hör kein Radio, ich hör das Sterben der deutschen Musikkultur.",
        "Kalle FM – hundert Prozent Lärm, null Prozent Niveau.",
        "Wenn das Radio wieder rauscht, halt ich's für Applaus."
    ],
    "trash": [
        "Finger weg! Das ist meine private Wertstoffsammlung.",
        "Hier drin liegt ein halber Döner, der mich beim Namen kennt.",
        "Man nennt es Müll. Ich nenn es Einrichtung.",
        "Ich hab da mal was Wertvolles reingeworfen. Meine Hoffnung.",
        "Fünf Sterne für dieses gastronomische Desaster."
    ],
    "table": [
        "Der Tisch steht nur noch, weil die Krümel ihn zusammenhalten.",
        "Das ist kein Aschenbecher, das ist ein geologisches Zeitalter.",
        "Räumst du hier auf, kündigt der Staub seinen Mietvertrag.",
        "Der Kaffee ist von gestern. Also von irgendeinem gestern."
    ],
    "door": [
        "Die Tür bleibt zu. Dahinter ist mein ganzes ungelöstes Leben.",
        "Klopf noch mal, dann klopf ich zurück. Vielleicht.",
        "Da hinter wohnt entweder Horst oder mein Schicksal.",
        "Was willst du in dem Flur? Da ist noch weniger los als hier!"
    ],
    "window": [
        "Draußen sieht's aus wie drinnen, nur mit besserer Belüftung.",
        "Das Fenster geht auf. Meine Lebensperspektive leider nicht.",
        "Guck mal: Frischluft! Widerlich. Mach wieder zu.",
        "Da draußen laufen Leute freiwillig zur Arbeit. Kranke Welt."
    ],
    "touch": [
        "Ey! Pfoten weg, du digitales Trampeltier!",
        "Was grapschst du mich an? Kauf dir 'nen Stressball!",
        "Noch ein Fingertipp und ich stell dir 'ne Rechnung.",
        "Ich bin keine verdammte Klingel, Kollege!",
        "Du hast viel Freizeit, oder? Ich seh's an deinem Finger.",
        "Was ist? Hängt dir die Touchscreen-Taste quer?"
    ],
    "floor": [
        "Ja, ja. Ich lauf ja schon, du kleiner Chef.",
        "Einen Schritt nach dem andern. Ich hab nur zwei Füße!",
        "Ich bin kein ferngesteuerter Staubsauger."
    ]
}

var kalle: Node2D
var ui_root: Control
var speech_panel: PanelContainer
var speech_label: Label
var info_panel: PanelContainer
var info_label: Label
var status_label: Label
var screen_glow: ColorRect
var night_tint: ColorRect
var audio_player: AudioStreamPlayer
var clock: float = 0.0
var ambient_countdown: float = 14.0
var pending_object: String = ""
var dialog_counter: int = 0
var last_lines: Array[String] = []
var counters: Dictionary = {"touch": 0, "lamp": 0, "tv": 0, "trash": 0, "door": 0}
var discoveries: Array[String] = []
var chaos: int = 0
var tv_on: bool = false
var radio_on: bool = false
var lamp_on: bool = true
var muted: bool = false
var sounds: Dictionary = {}
var object_zones: Array[Dictionary] = []

func _ready() -> void:
    randomize()
    _load_game()
    _build_world()
    _build_ui()
    _refresh_status()
    ambient_countdown = randf_range(10.0, 17.0)
    _intro_after_delay()

func _intro_after_delay() -> void:
    await get_tree().create_timer(1.0).timeout
    if is_instance_valid(speech_panel):
        _say(_random_line("intro"), 5.0)

func _build_world() -> void:
    var background: Sprite2D = Sprite2D.new()
    background.texture = load("res://assets/background/room.jpg") as Texture2D
    background.position = Vector2(640, 360)
    add_child(background)

    night_tint = ColorRect.new()
    night_tint.position = Vector2.ZERO
    night_tint.size = Vector2(1280, 720)
    night_tint.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var current_hour: int = int(Time.get_datetime_dict_from_system()["hour"])
    night_tint.color = Color(0.06, 0.14, 0.27, 0.26 if current_hour >= 20 or current_hour <= 5 else 0.04)
    add_child(night_tint)

    # The door and window are part of the room painting, but have independent touch areas.
    object_zones.append({"id": "door", "rect": Rect2(1085, 155, 190, 495)})
    object_zones.append({"id": "window", "rect": Rect2(24, 135, 265, 305)})

    var lamp := _make_prop("lamp", 0)
    var sofa := _make_prop("sofa", 1)
    var tv := _make_prop("tv", 1)
    var trash := _make_prop("trash", 1)
    var table := _make_prop("table", 1)
    var radio := _make_prop("radio", 2)
    # Avoid warnings when demo props are later extended.
    lamp.visible = true
    sofa.visible = true
    tv.visible = true
    trash.visible = true
    table.visible = true
    radio.visible = true

    screen_glow = ColorRect.new()
    screen_glow.color = Color(0.34, 0.82, 1.0, 0.16)
    screen_glow.position = Vector2(623, 353)
    screen_glow.size = Vector2(105, 90)
    screen_glow.visible = false
    screen_glow.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(screen_glow)

    kalle = KALLE_SCRIPT.new() as Node2D
    kalle.name = "Kalle"
    kalle.position = Vector2(741, GROUND_Y)
    kalle.z_index = 5
    add_child(kalle)
    kalle.connect("arrived", Callable(self, "_on_kalle_arrived"))

    audio_player = AudioStreamPlayer.new()
    add_child(audio_player)
    for sound_name in ["tap", "television", "radio", "secret"]:
        sounds[sound_name] = load("res://assets/audio/%s.wav" % sound_name)

func _make_prop(object_id: String, depth: int) -> Sprite2D:
    var info: Dictionary = PROP_SPECS[object_id]
    var prop: Sprite2D = Sprite2D.new()
    prop.name = object_id.capitalize()
    prop.texture = load("res://assets/props/%s.png" % object_id) as Texture2D
    prop.position = info["pos"]
    prop.scale = info["size"] / prop.texture.get_size()
    prop.z_index = depth
    add_child(prop)
    object_zones.append({"id": object_id, "rect": Rect2(prop.position - info["size"] / 2.0, info["size"])})
    return prop

func _make_button(title: String, x: float, width: float, callable: Callable) -> Button:
    var button: Button = Button.new()
    button.text = title
    button.position = Vector2(x, 16)
    button.size = Vector2(width, 51)
    button.add_theme_font_size_override("font_size", 17)
    button.pressed.connect(callable)
    ui_root.add_child(button)
    return button

func _build_ui() -> void:
    var layer: CanvasLayer = CanvasLayer.new()
    layer.name = "HUD"
    layer.layer = 10
    add_child(layer)
    ui_root = Control.new()
    ui_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    ui_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(ui_root)

    var header: ColorRect = ColorRect.new()
    header.color = Color(0.08, 0.06, 0.05, 0.79)
    header.position = Vector2.ZERO
    header.size = Vector2(1280, 82)
    header.mouse_filter = Control.MOUSE_FILTER_IGNORE
    ui_root.add_child(header)

    var title: Label = Label.new()
    title.text = "KALLE  /  DRECKSBUDE"
    title.position = Vector2(22, 16)
    title.size = Vector2(395, 42)
    title.add_theme_font_size_override("font_size", 27)
    title.add_theme_color_override("font_color", Color(1.0, 0.72, 0.34))
    ui_root.add_child(title)

    status_label = Label.new()
    status_label.position = Vector2(23, 57)
    status_label.add_theme_font_size_override("font_size", 12)
    status_label.add_theme_color_override("font_color", Color(0.9, 0.83, 0.73))
    ui_root.add_child(status_label)

    _make_button("SAMMLUNG", 746, 140, Callable(self, "_show_collection"))
    _make_button("HILFE", 896, 108, Callable(self, "_show_help"))
    _make_button("TON AN/AUS", 1014, 130, Callable(self, "_toggle_sound"))
    _make_button("X", 1155, 95, Callable(self, "_close_info"))

    speech_panel = PanelContainer.new()
    speech_panel.position = Vector2(314, 93)
    speech_panel.custom_minimum_size = Vector2(650, 70)
    speech_panel.visible = false
    speech_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    ui_root.add_child(speech_panel)
    speech_label = Label.new()
    speech_label.custom_minimum_size = Vector2(630, 56)
    speech_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    speech_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    speech_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    speech_label.add_theme_font_size_override("font_size", 21)
    speech_label.add_theme_color_override("font_color", Color(0.1, 0.08, 0.07))
    speech_panel.add_child(speech_label)

    info_panel = PanelContainer.new()
    info_panel.position = Vector2(365, 195)
    info_panel.custom_minimum_size = Vector2(550, 330)
    info_panel.visible = false
    info_panel.mouse_filter = Control.MOUSE_FILTER_STOP
    ui_root.add_child(info_panel)
    info_label = Label.new()
    info_label.custom_minimum_size = Vector2(535, 300)
    info_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    info_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    info_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    info_label.add_theme_font_size_override("font_size", 22)
    info_label.add_theme_color_override("font_color", Color(0.1, 0.08, 0.07))
    info_panel.add_child(info_label)

    var hint: Label = Label.new()
    hint.text = "TIPPE AUF KALLE ODER MÖBEL  •  TIPPE AUF DEN BODEN, DAMIT KALLE HINLÄUFT"
    hint.position = Vector2(26, 683)
    hint.size = Vector2(1230, 24)
    hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    hint.add_theme_font_size_override("font_size", 16)
    hint.add_theme_color_override("font_color", Color(1.0, 0.9, 0.65))
    ui_root.add_child(hint)

func _unhandled_input(event: InputEvent) -> void:
    if not event is InputEventMouseButton:
        return
    if event.button_index != MOUSE_BUTTON_LEFT or not event.pressed:
        return
    if info_panel.visible:
        _close_info()
        get_viewport().set_input_as_handled()
        return
    var p: Vector2 = get_global_mouse_position()
    # Character hit-testing, avoiding permanent text overlay obstruction.
    if absf(p.x - kalle.position.x) < 75 and p.y > kalle.position.y - 360 and p.y < kalle.position.y + 8:
        _interact_with_kalle()
        get_viewport().set_input_as_handled()
        return
    # Reverse creation order: radio (on top of table) wins over the table.
    for i in range(object_zones.size() - 1, -1, -1):
        var item: Dictionary = object_zones[i]
        if (item["rect"] as Rect2).has_point(p):
            _go_to_object(item["id"])
            get_viewport().set_input_as_handled()
            return
    if p.y > 330 and p.y < 685:
        pending_object = ""
        (kalle as Node2D).call("walk_to", p.x)
        if randf() < 0.22:
            _say(_random_line("floor"), 3.5)
        get_viewport().set_input_as_handled()

func _go_to_object(id: String) -> void:
    pending_object = id
    var approach_x: float = 0.0
    match id:
        "door": approach_x = 1150.0
        "window": approach_x = 385.0
        _: approach_x = float(PROP_SPECS[id]["approach"])
    (kalle as Node2D).call("walk_to", approach_x)

func _on_kalle_arrived() -> void:
    if pending_object.is_empty():
        return
    var id: String = pending_object
    pending_object = ""
    _interact_with_object(id)

func _interact_with_kalle() -> void:
    counters["touch"] = int(counters.get("touch", 0)) + 1
    chaos = mini(999, chaos + 1)
    (kalle as Node2D).call("emote", "angry")
    _play("tap")
    _say(_random_line("touch"), 4.0)
    if int(counters["touch"]) == 12:
        _unlock("Touchscreen-Terror", "Zwölfmal angefasst. Kalle will jetzt Schmerzensgeld.")
    _reset_mood_later(2.1)
    _refresh_status()
    _save_game()

func _interact_with_object(id: String) -> void:
    chaos = mini(999, chaos + 1)
    if counters.has(id):
        counters[id] = int(counters[id]) + 1
    _say(_random_line(id), 4.6)
    _play("tap")
    match id:
        "tv":
            tv_on = not tv_on
            screen_glow.visible = tv_on
            _play("television")
            if int(counters["tv"]) >= 7:
                _unlock("Fernsehfluch", "Der Fernseher flimmert und flüstert: 'Ich seh dich, Kalle!' ")
        "radio":
            radio_on = not radio_on
            _play("radio")
            if radio_on and randf() < 0.15:
                _say("KALLE FM: Jetzt die größten Hits aus der Restmülltonne!", 4.2)
        "lamp":
            lamp_on = not lamp_on
            var tint: Color = night_tint.color
            tint.a = 0.17 if lamp_on else 0.36
            night_tint.color = tint
            if int(counters["lamp"]) >= 3:
                _unlock("Flacker-Hölle", "Dreimal geschaltet – selbst die Glühbirne hat gekündigt.")
        "trash":
            if int(counters["trash"]) >= 5:
                _unlock("Goldener Löffel", "Zwischen Pizzakarton und Restmüll: der legendäre goldene Löffel!")
        "door":
            if int(counters["door"]) >= 5:
                _unlock("Horst klopft zurück", "Eine Stimme hinter der Tür: 'KALLE! ICH WILL MEINE MIETE!' ")
        "table":
            if randf() < 0.12:
                _say("Ich glaub, die Kaffeetasse hat gerade einen Scheidungsanwalt bestellt.", 4.2)
    _refresh_status()
    _save_game()

func _unlock(id: String, description: String) -> void:
    if discoveries.has(id):
        return
    discoveries.append(id)
    chaos = mini(999, chaos + 10)
    _play("secret")
    (kalle as Node2D).call("emote", "dance")
    _say("GEHEIMNIS: " + description, 6.0)
    _reset_mood_later(3.2)

func _random_line(category: String) -> String:
    var items: Array = PHRASES.get(category, PHRASES["idle"])
    var pool: Array[String] = []
    for item in items:
        if not last_lines.has(String(item)):
            pool.append(String(item))
    if pool.is_empty():
        for item in items:
            pool.append(String(item))
    var chosen: String = pool.pick_random()
    last_lines.append(chosen)
    if last_lines.size() > 8:
        last_lines.pop_front()
    return chosen

func _say(message: String, seconds: float = 4.0) -> void:
    dialog_counter += 1
    speech_label.text = message
    speech_panel.visible = true
    _hide_speech_after(seconds, dialog_counter)

func _hide_speech_after(seconds: float, token: int) -> void:
    await get_tree().create_timer(seconds).timeout
    if is_instance_valid(speech_panel) and token == dialog_counter:
        speech_panel.hide()

func _reset_mood_later(seconds: float) -> void:
    await get_tree().create_timer(seconds).timeout
    if is_instance_valid(kalle) and not bool(kalle.get("traveling")):
        (kalle as Node2D).call("emote", "idle")

func _play(key: String) -> void:
    if muted:
        return
    if sounds.has(key):
        audio_player.stop()
        audio_player.stream = sounds[key]
        audio_player.volume_db = -10.0
        audio_player.play()

func _process(delta: float) -> void:
    clock += delta
    ambient_countdown -= delta
    if screen_glow.visible:
        var glow: Color = screen_glow.color
        glow.a = 0.1 + absf(sin(clock * 2.2)) * 0.2
        screen_glow.color = glow
    if ambient_countdown <= 0.0:
        ambient_countdown = randf_range(11.0, 21.0)
        if pending_object.is_empty() and not bool(kalle.get("traveling")):
            if randf() < 0.48:
                (kalle as Node2D).call("walk_to", randf_range(380.0, 1080.0))
            elif randf() < 0.7:
                _say(_random_line("idle"), 4.4)
            else:
                (kalle as Node2D).call("emote", "dance")
                _reset_mood_later(2.5)

func _show_collection() -> void:
    var data: String = "KALLES GEHEIMSAMMLUNG\n\n"
    if discoveries.is_empty():
        data += "Noch keine Geheimnisse gefunden.\nKalle behauptet, es gäbe sowieso keine.\n\n"
    else:
        for item in discoveries:
            data += "★ " + item + "\n"
        data += "\n"
    data += "Geheimnisse: %d/5\nChaos-Punkte: %d\n\nTipp: Untersuche manche Dinge öfter!" % [discoveries.size(), chaos]
    info_label.text = data
    info_panel.show()

func _show_help() -> void:
    info_label.text = "KALLE – DRECKSBUDE / V0.1\n\n" + \
        "Tippe auf den Boden: Kalle läuft hin.\n" + \
        "Tippe auf Kalle: Freche Reaktion.\n" + \
        "Tippe auf Möbel: Kalle benutzt sie.\n" + \
        "Tippe mehrfach auf manche Gegenstände.\n\n" + \
        "Alles läuft offline.\nFortschritt wird automatisch gespeichert.\n\n" + \
        "Ein Raum – keine hektischen Szenenwechsel!"
    info_panel.show()

func _close_info() -> void:
    info_panel.hide()

func _toggle_sound() -> void:
    muted = not muted
    _say("Ton aus. Endlich Ruhe!" if muted else "Ton an. Na toll, jetzt hörst du mich wieder!", 3.5)
    _save_game()

func _refresh_status() -> void:
    status_label.text = "CHAOS: %d   |   GEHEIMNISSE: %d/5   |   EIN RAUM, EINE VERDAMMTE WELT" % [chaos, discoveries.size()]

func _save_game() -> void:
    var data: Dictionary = {
        "version": 1, "chaos": chaos, "counters": counters,
        "discoveries": discoveries, "muted": muted
    }
    var json: String = JSON.stringify(data)
    var file: FileAccess = FileAccess.open(SAVE_FILE, FileAccess.WRITE)
    if file != null:
        file.store_string(json)
        file.close()

func _load_game() -> void:
    if not FileAccess.file_exists(SAVE_FILE):
        return
    var file: FileAccess = FileAccess.open(SAVE_FILE, FileAccess.READ)
    if file == null:
        return
    var parsed: Variant = JSON.parse_string(file.get_as_text())
    file.close()
    if not parsed is Dictionary:
        return
    var data: Dictionary = parsed
    chaos = clampi(int(data.get("chaos", 0)), 0, 999)
    muted = bool(data.get("muted", false))
    var saved_counters: Variant = data.get("counters", {})
    if saved_counters is Dictionary:
        for key in counters.keys():
            counters[key] = maxi(0, int(saved_counters.get(key, 0)))
    var saved_discoveries: Variant = data.get("discoveries", [])
    if saved_discoveries is Array:
        for entry in saved_discoveries:
            var id: String = String(entry)
            if not discoveries.has(id) and discoveries.size() < 5:
                discoveries.append(id)
